package com.example.demo_books;

import org.junit.jupiter.api.Test;
import org.springframework.boot.test.context.SpringBootTest;

@SpringBootTest
class DemoBooksApplicationTests {

	@Test
	void contextLoads() {
	}

}
