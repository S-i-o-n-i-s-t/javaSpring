package com.example.dz_6;

import org.junit.jupiter.api.Test;
import org.springframework.boot.test.context.SpringBootTest;

@SpringBootTest
class Dz6ApplicationTests {

	@Test
	void contextLoads() {
	}

}
