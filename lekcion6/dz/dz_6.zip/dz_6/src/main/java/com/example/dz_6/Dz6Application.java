package com.example.dz_6;

import org.springframework.boot.SpringApplication;
import org.springframework.boot.autoconfigure.SpringBootApplication;

@SpringBootApplication
public class Dz6Application {

	public static void main(String[] args) {
		SpringApplication.run(Dz6Application.class, args);
	}

}
