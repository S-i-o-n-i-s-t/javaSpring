package com.example.taskDZ;

import org.junit.jupiter.api.Test;
import org.springframework.boot.test.context.SpringBootTest;

@SpringBootTest
class TaskDzApplicationTests {

	@Test
	void contextLoads() {
	}

}
