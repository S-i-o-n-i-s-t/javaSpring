package com.example.test_2;

import org.junit.jupiter.api.Test;
import org.springframework.boot.test.context.SpringBootTest;

@SpringBootTest
class Test2ApplicationTests {

	@Test
	void contextLoads() {
	}

}
